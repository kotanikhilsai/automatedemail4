class automl:
    def __init__(self):
        self.x='automailpy3@gmail.com'
        self.y='auto_mailpy3'
        
    def autom(self,r,sub,msg):
        import smtplib
        s='Subject:'+sub+'\n'+msg
        eobj=smtplib.SMTP('smtp.gmail.com',587)
        eobj.ehlo()
        eobj.starttls()
        eobj.login(self.x,self.y)
        eobj.sendmail('automailpy3@gmail.com',r,s)
        eobj.quit()
        print("email succesfully sent")
    def log(self,x,y):
        self.x=x
        self.y=y
    
